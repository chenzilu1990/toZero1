import nuke, os
import extractSelectedShapes
#import gerenateTransform
nukeMenu = nuke.menu('Nuke')
toolbar=nuke.toolbar("Nodes")
nukeMenu.addCommand('fenC',extractSelectedShapes.extractSelectedShapes)


# toolbar.addCommand("SBNodes/extractSelectedShapes",extractSelectedShapes.extractSelectedShapes)
# toolbar.addCommand("SBNodes/roto","nuke.nodes.RotoPaint()")
toolbar.addCommand("SBNodes/M_depthColor","nuke.createNode('M_depthColor')","#m")
toolbar.addCommand("SBNodes/LSJOffSet","nuke.createNode('LSJOffSet')","#q")

#NukeFXSExporter
nuke.tprint('Loading NukeFXSExporter.py')
try:
	#import NukeFXSExporter
    from NukeFXSExporter import *
except:
    pass

#===============================================================================
# BVFX ToolBar Menu definitions
#===============================================================================
toolbar = nuke.menu("Nodes")
bvfxt = toolbar.addMenu("BoundaryVFX Tools", "BoundaryVFX.png")
bvfxt.addCommand('Silhouette FXS exporter', 'silhouetteFxsExporter()', icon='BoundaryVFX.png')


#===============================================================================
# Uncomment the code below to enable automatic file saving to a predefined path/file
#===============================================================================
#os.environ['FXSEXPORTPATH'] = '/path/to/your/fxsfile.fxs'
