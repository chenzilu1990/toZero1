
roto=nuke.selectedNode()
for x in range(10):
    tf=nuke.nodes.Transform(inputs=[roto])
    tf["translate"].splitView()  
    tf["translate"].setValue((-x,0),view='left')
    tf["translate"].setValue((x,0),view='right')

    
