{
	function depthController(thisObj) {
		scriptName = "SBDepthContrller11.23"

		function onCollectClick() {
			var activeItem = app.project.activeItem;
			if ((activeItem == null) || !(activeItem instanceof CompItem)) {
				alert("请选择或打开一个合成.", scriptName);
			} else {
				var selectedLayers = activeItem.selectedLayers;
				if (selectedLayers.length == 0) {
					alert("至少选择一个图层	", scriptName);
				} else {
					app.beginUndoGroup(scriptName);
					depthController = activeItem.layers.add(selectedLayers[0].source)
					depthController.name = "depthController"
					depthController.enabled = false
					// depthController = activeItem.layers.addNull()
					
					// alert(
					for (var i = 0; i < selectedLayers.length; i++) {
						var aSelLayer =	selectedLayers[i];
						
						
						if (depthController.effect.canAddProperty("Color Control")) {
							depthController.effect.addProperty("Color Control")
							var start = depthController.effect.property("Color Control")
							start.name = aSelLayer.name + " start"
							start.property("Color").setValue([1,1,1,1])

							depthController.effect.addProperty("Color Control")
							var end = depthController.effect.property("Color Control")
							end.name = aSelLayer.name + " end"
							end.property("Color").setValue([0,0,0,0])
						
							
					
						}
						
						
						if (aSelLayer.effect.canAddProperty("Gradient Ramp")) {
							
							if (aSelLayer.effect.property("Gradient Ramp") == null) {

								aSelLayer.effect.addProperty("Gradient Ramp")
							}
							
							
							if (aSelLayer.effect.property("Gradient Ramp").property("Start Color").canSetExpression) {
								
								aSelLayer.effect.property("Gradient Ramp").property("Start Color").expression = 'thisComp.layer("'+ depthController.name +'").effect("'+ aSelLayer.name + " start"+'")("Color")' 
								 
							}

							if (aSelLayer.effect.property("Gradient Ramp").property("End Color").canSetExpression) {
							
								aSelLayer.effect.property("Gradient Ramp").property("End Color").expression = 'thisComp.layer("'+ depthController.name +'").effect("'+ aSelLayer.name + " end"+'")("Color")' 
								
							}
							

						}
												
					}
					


					app.endUndoGroup();
				}
			}	
		}


		function collectPoint() {
			// alert(72)
			var activeItem = app.project.activeItem;
			if ((activeItem == null) || !(activeItem instanceof CompItem)) {
				alert("请选择或打开一个合成.", scriptName);
			} else {
				var selectedLayers = activeItem.selectedLayers;
				if (selectedLayers.length == 0) {
					alert("至少选择一个图层	", scriptName);
				} else {
					app.beginUndoGroup(scriptName);
					// alert(83)
					// alert(selectedLayers[0].source)
					pointController = activeItem.layers.add(selectedLayers[0].source)
					pointController.name = "pointController"
					pointController.enabled = false
					// alert(depthController.width)
					// depthController.width = 200
					// alert(88)
					var position = pointController.transform.property("Position").value
					// alert(position[0])
					for (var i = 0; i < selectedLayers.length; i++) {
						var aSelLayer =	selectedLayers[i];
						

						if (pointController.effect.canAddProperty("Point Control")) {
							pointController.effect.addProperty("Point Control")
							var start = pointController.effect.property("Point Control")
							start.name = aSelLayer.name + " start"
							// alert(97)
							start.property("Point").setValue([position[0],position[1]])
							pointController.effect.addProperty("Point Control")
							var end = pointController.effect.property("Point Control")
							end.name = aSelLayer.name + " end"
							end.property("Point").setValue([0,0])
					
							
					
						}
						// alert(37)
						
						if (aSelLayer.effect.canAddProperty("Gradient Ramp")) {
							// alert(aSelLayer.effect.property("Gradient Ramp") != null)
							if (aSelLayer.effect.property("Gradient Ramp") == null) {

								aSelLayer.effect.addProperty("Gradient Ramp")
							}
							
							
							if (aSelLayer.effect.property("Gradient Ramp").property("Start of Ramp").canSetExpression) {
								
								aSelLayer.effect.property("Gradient Ramp").property("Start of Ramp").expression = 'thisComp.layer("'+ pointController.name +'").effect("'+ aSelLayer.name + " start"+'")("Point")' 
								 
							}

							if (aSelLayer.effect.property("Gradient Ramp").property("End of Ramp").canSetExpression) {
							
								aSelLayer.effect.property("Gradient Ramp").property("End of Ramp").expression = 'thisComp.layer("'+ pointController.name +'").effect("'+ aSelLayer.name + " end"+'")("Point")' 
								
							}
							// alert(125)

						}
												
					}
					


					app.endUndoGroup();
				}
			}

			
		}

		// 
		// This function puts up a modal dialog asking for a scale_factor.
		// Once the user enters a value, the dialog closes, and the script scales the comp.
		// 

		function BuildAndShowUI(thisObj) {
			// Create and show a floating palette.
			var my_palette = (thisObj instanceof Panel) ? thisObj : new Window("palette", scriptName, undefined, {resizeable:true});
			if (my_palette != null) {
				var res = 
							"group { \
								orientation:'column', alignment:['fill','top'], alignChildren:['left','top'], spacing:5, margins:[0,0,0,0], \
								cmds: Group { \
									alignment:['fill','top'], \
									collectButton: Button { text:'depth控制面板', alignment:['fill','center'] }, \
									collectButton1: Button { text:'point控制面板', alignment:['fill','center'] }, \
								}, \
							}"
				
// 
//
// 
// 
// 
// 
// 
// 					
				my_palette.grp = my_palette.add(res); 
				my_palette.grp.cmds.collectButton.onClick = onCollectClick;
				my_palette.grp.cmds.collectButton1.onClick = collectPoint;
				my_palette.onResizing = my_palette.onResize = function () {this.layout.resize();}

				// my_palette.margins = [10,10,10,10];
			}
			return my_palette;
		}

		// 
		// The main script.
		//
		if (parseFloat(app.version) < 8) {
			alert("This script requires After Effects CS3 or later.", scriptName);
			return;
		}
		var my_palette = BuildAndShowUI(thisObj);
		if (my_palette != null) {
			if (my_palette instanceof Window) {

				my_palette.center();
				my_palette.show();
			} else {

				my_palette.layout.layout(true);
				my_palette.layout.resize();
			}
		} else {
			alert("Could not open the user interface.", scriptName);
		}

	}
	depthController(this)
}