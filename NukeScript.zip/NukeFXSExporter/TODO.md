TODO Code implementation list
===============
* Implement Layer opacity as multiplier to the child shapes opacity
* Figure out the rectangle shape tangents issue that happens sometimes: Draw a rectangle bezier and the tangents will be exported swapped.

* SOLVED (with error msg) - Sometimes if elements are selected oin the roto node, script fails
* SOLVED - Unique shape/layer name verification/fix
* SOLVED - Verify if root layers with transforms are working correctly
* SOLVED - Remove repeated keyframes from transform matrices
* SOLVED - Identify linear/constant keyframes shape point animation to avoid baking them.

